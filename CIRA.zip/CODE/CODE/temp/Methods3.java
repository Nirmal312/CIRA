public class Methods3 {
    public static void main(String[] args) {
        Methods3 m = new Methods3();
        m.temp();
    }

    public void temp(){
        System.out.println("Hi from temp method");
    }
}
