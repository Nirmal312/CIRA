import java.util.Arrays;

public class Methods2 {
    public static void main(String[] args) {
        int[] arr = array();
        System.out.println(Arrays.toString(arr));
    }
    public static int[] array(){
        int[] a = new int[5];
        return a;
    }
}
