# Methods in Java

## Definition

    - A **method** in Java is a block of code that performs a specific task.
    - Methods help in organizing code, reducing repetition, and improving readability.
    - A method is executed when it is called.

### Example

```java
public class Demo {
    static void greet() {
        System.out.println("Hello, Welcome to Java!");
    }

    public static void main(String[] args) {
        greet(); // Method call
    }
}
```

---

# Advantages of Methods in Java

### 1. Code Reusability

A method can be called multiple times without rewriting the same code.

### 2. Reduces Code Duplication

The same logic can be placed in a method and used whenever needed.

### 3. Improves Readability

Methods divide a large program into smaller, understandable parts.

### 4. Easier Debugging

Errors can be identified and fixed in specific methods.

### 5. Better Program Organization

Methods help structure programs logically.

### 6. Easy Maintenance

Changes made in one method are automatically reflected wherever it is called.

---

# Syntax of a Method

```java
access_modifier return_type method_name(parameters) {
    // Method body
}
```

### Example

```java
public int add(int a, int b) {
    return a + b;
}
```

### Explanation

* **public** → Access modifier
* **int** → Return type
* **add** → Method name
* **(int a, int b)** → Parameters
* **return a + b;** → Returns the result

---

# Types of Methods in Java

## 1. Predefined Methods

Methods already provided by Java libraries.

### Example

```java
public class Demo {
    public static void main(String[] args) {
        System.out.println("Java");
        Math.sqrt(25);
    }
}
```

* `println()`
* `sqrt()`

are predefined methods.

---

## 2. User-Defined Methods

Methods created by the programmer.

### Example

```java
public class Demo {
    static void display() {
        System.out.println("User Defined Method");
    }

    public static void main(String[] args) {
        display();
    }
}
```

---

# Types Based on Parameters and Return Type

## 1. No Parameters and No Return Type

```java
class Demo {
    static void show() {
        System.out.println("Hello");
    }

    public static void main(String[] args) {
        show();
    }
}
```

---

## 2. Parameters and No Return Type

```java
class Demo {
    static void add(int a, int b) {
        System.out.println("Sum = " + (a + b));
    }

    public static void main(String[] args) {
        add(10, 20);
    }
}
```

---

## 3. No Parameters but Return Type

```java
class Demo {
    static int getNumber() {
        return 100;
    }

    public static void main(String[] args) {
        System.out.println(getNumber());
    }
}
```

---

## 4. Parameters and Return Type

```java
class Demo {
    static int multiply(int a, int b) {
        return a * b;
    }

    public static void main(String[] args) {
        int result = multiply(5, 4);
        System.out.println(result);
    }
}
```

---

# Summary Table

| Type   | Parameters | Return Type |
| ------ | ---------- | ----------- |
| Type 1 | No         | No          |
| Type 2 | Yes        | No          |
| Type 3 | No         | Yes         |
| Type 4 | Yes        | Yes         |

### Example Methods

* `void show()` → No parameters, No return type
* `void add(int a, int b)` → Parameters, No return type
* `int getValue()` → No parameters, Return type
* `int sum(int a, int b)` → Parameters, Return type

**A method is a reusable block of code that performs a specific task and helps make Java programs modular, readable, and maintainable.**
