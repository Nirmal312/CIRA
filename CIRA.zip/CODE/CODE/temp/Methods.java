public class Methods{
    public static void main(String[] args) {
        add1();
        add2(1, 2);
        int sum3 = add3();
        System.out.println(sum3);
        int sum4 = add4(4, 3);
        System.out.println("sum4 : " + sum4);

    }

    // without parameter and without return value
    public static void add1(){
        System.out.println("Hi from add method");
    }

    // parameter and without return value
    public static void add2(int a, int b){
        System.out.println("Sum : " + (a+b));
    }

    // without parameter and return value
    public static int add3(){
        return 234;
    }

    // with parameter and with return value
    public static int add4(int a, int b){
        return a+b;
    }
}




TASK
1. display area of circle, square, rectangle
2. user input 1 -> circle, 2-> square, 3-> rectangle, other invalid input
3. circle()
4. pi, r
5. print area of a shape  